# Scraping application

![landingpage](./screen/Screenshot_1.png)
![landingpage](./screen/Screenshot_2.png)
![landingpage](./screen/Screenshot_3.png)